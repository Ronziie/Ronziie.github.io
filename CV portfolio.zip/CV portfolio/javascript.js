const myCarousel = document.querySelector('#myCarousel')
const carousel = new mdb.Carousel(myCarousel)


$('.collapse').collapse()
$('.collapse').collapse()

